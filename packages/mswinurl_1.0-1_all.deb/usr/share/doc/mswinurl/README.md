ubuntu-mswinurl
===============

Ubuntu scripts to handle the mimetype application/x-mswinurl .URL Windows file